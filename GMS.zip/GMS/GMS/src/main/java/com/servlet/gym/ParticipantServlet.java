package com.servlet.gym;


import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.gym.ParticipantDAO;
import com.model.gym.Participants;

/**
 * Servlet implementation class Participant_s
 */
@WebServlet("/")
public class ParticipantServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ParticipantDAO participantdao;

    /**
     * Default constructor. 
     */
    public ParticipantServlet() {
        this.participantdao = new ParticipantDAO();
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		
		switch(action){
		case "/newParticipant":
			showNewForm(request, response);
			break;
		case "/insertParticipant":
			try {
				insertParticipant(request, response);
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Error aa rha hai... insert participant me..");
			}
			break;
		case "/deleteParticipant":
			try {
				deleteParticipant(request, response);
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/editParticipant":
			try {
				showEditForm(request, response);
			} catch (ServletException | SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/updateParticipant":  //
			try {
				updateParticipant(request, response);
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		default:
			try {
				listParticipant(request, response);
			} catch (SQLException | IOException | ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
	}
	
	private void showNewForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("participant-form.jsp");   //participant-list.jsp
		dispatcher.forward(request, response);
	}
	
	//create
	private void insertParticipant(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String phoneno = request.getParameter("phoneno");
			Participants newParticipant = new Participants(name, email, phoneno);
			participantdao.insertParticipant(newParticipant);
			response.sendRedirect("listparticipants");		
		}
	
	//Select all
	private void listParticipant(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException{
		List<Participants> listParticipant = participantdao.selectAllParticipants();
		request.setAttribute("listParticipant", listParticipant);
		RequestDispatcher dispatcher = request.getRequestDispatcher("participant-list.jsp");
		dispatcher.forward(request, response);
		
	}
	
	//update
	private void updateParticipant(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String phoneno = request.getParameter("phoneno");
		
		Participants participant = new Participants(id, name, email, phoneno);
		participantdao.updateParticipant(participant);
		response.sendRedirect("listparticipants");		
	}	
	
	//delete
	private void deleteParticipant(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException{
		int id = Integer.parseInt(request.getParameter("id"));
		participantdao.deleteParticipant(id);
		response.sendRedirect("listparticipants");
	} 
	
	//selectbyid
	private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, SQLException, IOException{
		int id = Integer.parseInt(request.getParameter("id"));
		Participants existingParticipant = participantdao.selectParticipant(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("participant-form.jsp");
		request.setAttribute("participant", existingParticipant);
		dispatcher.forward(request, response);		
	}
	
	
	
}
