package com.servlet.gym;


import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.time.LocalDate;
import java.util.List;



import com.dao.gym.BatchDAO;
import com.model.gym.Batch;
import com.model.gym.Participants;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Servlet implementation class Participant_s
 */
@WebServlet("/BatchServlet")
public class BatchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BatchDAO batchdao;

    /**
     * Default constructor. 
     */
    public BatchServlet() {
        this.batchdao = new BatchDAO();
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		
		switch(action){
		case "/newBatch":
			showNewForm(request, response);
			break;
		case "/insertBatch":
			try {
				insertBatch(request, response);
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/deleteBatch":
			try {
				deleteBatch(request, response);
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/editBatch":
			try {
				showEditForm(request, response);
			} catch (ServletException | SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/updateBatch":
			try {
				updateBatch(request, response);
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace(); 
			}
			break;
		default:
			try {
				listBatch(request, response);
			} catch (SQLException | IOException | ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
	}
	
	
	//Select all
	private void listBatch(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException{
		List<Batch> listBatch = batchdao.selectAllBatch();
		request.setAttribute("listBatch", listBatch);
		RequestDispatcher dispatcher = request.getRequestDispatcher("batch-list.jsp");
		dispatcher.forward(request, response);
		
	}
	
	//update
	private void updateBatch(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		
		
		String batchName = request.getParameter("batchName");
		String startDate = request.getParameter("startDate");
		String endDate =   request.getParameter("endDate");
		String sessionTime = request.getParameter("sessionTime");
		int batchId = Integer.parseInt(request.getParameter("batchId"));
		
		Batch batch = new Batch(batchId,batchName, startDate, endDate, sessionTime);
		batchdao.updateBatch(batch);
		response.sendRedirect("listbatches");	
		}
		
		
	//delete
	private void deleteBatch(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException{
		int batchId = Integer.parseInt(request.getParameter("batchId"));
		batchdao.deleteBatch(batchId);
		response.sendRedirect("listbatches");
	} 
	
	//selectbyid
	private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, SQLException, IOException , NumberFormatException {
		
			int batchId =Integer.parseInt(request.getParameter("batchId")); // Get the "id" parameter as a string
			Batch existingBatch = batchdao.selectBatch(batchId);
			RequestDispatcher dispatcher = request.getRequestDispatcher("batch-form.jsp");
			request.setAttribute("batch", existingBatch);
			dispatcher.forward(request, response);		
			}
	
	
	private void showNewForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("batch-form.jsp");
		dispatcher.forward(request, response);
	}
	
	//create
	private void insertBatch(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		
		    String batchName = request.getParameter("batchName");
		    String startDate = request.getParameter("startDate");
		    String endDate = request.getParameter("endDate");
		    String sessionTime = request.getParameter("sessionTime");
    
	    try
	    {  
	        Batch batch = new Batch(batchName, startDate, endDate, sessionTime);
		    batchdao.insertBatch(batch);
		    response.sendRedirect("listbatches");
		        
		}
		    catch(Exception e)
	    {
			e.printStackTrace();
	    }
	}	
}
