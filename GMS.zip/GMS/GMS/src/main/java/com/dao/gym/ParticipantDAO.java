package com.dao.gym;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.gym.Participants;

public class ParticipantDAO {
	private String jdbcURL = "jdbc:mysql://localhost:3306/gym_db"; 
	private String jdbcUsername = "root";
	private String jdbcPassword = "root";
	
	private static final String INSERT_PARTICIPANTS_SQL = "INSERT INTO participants" + "(name, email, phoneno) VALUES" + "(?, ?, ?);";
	private static final String SELECT_PARTICIPANTS_BY_ID = "select id,name,email,phoneno from participants where id =?";
	private static final String SELECT_ALL_PARTICIPANTS = "select * from participants";
	private static final String DELETE_PARTICIPANTS_SQL = "delete from participants where id =?;";
	private static final String UPDATE_PARTICIPANTS_SQL = "update participants set name=?, email=?, phoneno=? where id =?;";
	
	protected Connection getConnection() {
		Connection con = null;
		try {
		Class.forName( "com.mysql.cj.jdbc.Driver"); // Driver name
	    con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		}catch (SQLException e) {
		e.printStackTrace();
		}catch (ClassNotFoundException e) {
		e.printStackTrace();
		}
	return con;

	}
	//CREATE PARTICIPANT
	public void insertParticipant(Participants participant) throws SQLException{
		try(Connection con = getConnection();
			PreparedStatement preparedStatement = con.prepareStatement(INSERT_PARTICIPANTS_SQL)){
			preparedStatement.setString(1, participant.getName());
			preparedStatement.setString(2, participant.getEmail());
			preparedStatement.setString(3, participant.getPhoneno());
			preparedStatement.executeUpdate();
			System.out.println("data inserted successfully..");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//UPDATE PARTICIPANT 
	public boolean updateParticipant(Participants participant) throws SQLException{
		boolean rowUpdated;
		try(Connection con = getConnection();
				PreparedStatement statement = con.prepareStatement(UPDATE_PARTICIPANTS_SQL)){
				statement.setString(1, participant.getName());
				statement.setString(2, participant.getEmail());
				statement.setString(3, participant.getPhoneno());
				statement.setInt(4, participant.getId());
		         //	System.out.println(statement);
			rowUpdated = statement.executeUpdate()>0;
			
			System.out.println("data updated sucessfully..");
		}
		return rowUpdated;
	}
	
	
	// SELECT_PARTICIPANT_BY_ID
	public Participants selectParticipant(int id) {
		Participants participant = null;
		try(Connection con = getConnection();
				PreparedStatement preparedStatement = con.prepareStatement(SELECT_PARTICIPANTS_BY_ID);){
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()){
				String name = rs.getString("name");
				String email = rs.getString("email");
				String phoneno = rs.getString("phoneno");
				participant = new Participants(id, name, email, phoneno);
				System.out.println(participant);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return participant;
	}
	
	//SelectAllUsers
	public List<Participants> selectAllParticipants() {
		List<Participants> participants = new ArrayList<>();
		try(Connection con = getConnection();
				PreparedStatement preparedStatement = con.prepareStatement(SELECT_ALL_PARTICIPANTS);){
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()){
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String email = rs.getString("email");
				String phoneno = rs.getString("phoneno");
				participants.add(new Participants(id, name, email, phoneno));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return participants;
	}
	
	//DeleteUsers
	public boolean deleteParticipant(int id) throws SQLException{
		boolean rowDeleted;
		try(Connection con = getConnection();
				PreparedStatement statement = con.prepareStatement(DELETE_PARTICIPANTS_SQL);){
			statement.setInt(1, id);			
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}	
	
	
	
	
}
	
