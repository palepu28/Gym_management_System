package com.dao.gym;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;
import com.model.gym.Batch;


public class BatchDAO {
	private String jdbcURL = "jdbc:mysql://localhost:3306/gym_db"; 
	private String jdbcUsername = "root";
	private String jdbcPassword = "root";
	
	private static final String INSERT_BATCH_SQL = "INSERT INTO batch" + "(batchName, startDate, endDate,sessionTime) VALUES" + "(?, ?, ?, ?);";
	private static final String SELECT_BATCH_BY_ID = "select batchId,batchName,startDate,endDate, sessionTime from batch where batchId =?";
	private static final String SELECT_ALL_BATCHES = "select * from batch";
	private static final String DELETE_BATCH_SQL = "delete from batch where batchId =?;";
	private static final String UPDATE_BATCHES_SQL = "update batch set batchName=?, startDate=?, endDate=?, sessionTime=? where batchId =?;";
	
	protected Connection getConnection() {
		Connection con = null;
		try {
		Class.forName( "com.mysql.cj.jdbc.Driver"); // Driver name
	    con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		}catch (SQLException e) {
		e.printStackTrace();
		}catch (ClassNotFoundException e) {
		e.printStackTrace();
		}
	return con;

	}
	//CREATE PARTICIPANT
	public void insertBatch(Batch batch) throws SQLException{
		try(Connection con = getConnection();
				PreparedStatement preparedStatement = con.prepareStatement(INSERT_BATCH_SQL)){
			if (batch.getStartDate() != null && batch.getEndDate() != null && batch.getSessionTime() != null) {
		            preparedStatement.setString(1, batch.getBatchName());
		            preparedStatement.setString(2, batch.getStartDate());
		            preparedStatement.setString(3, batch.getEndDate());
		            preparedStatement.setString(4, batch.getSessionTime());
		            
		            int rowsInserted = preparedStatement.executeUpdate();
		            if (rowsInserted > 0) {
		                System.out.println("Data inserted successfully.");
		            } else {
		                System.out.println("Failed to insert data.");
		            }
		        } else {
		            System.out.println("Error: Null date values.");
		            // Optionally, you can throw an exception or handle the error as per your application's requirement
		        }
		    } catch (SQLException e) {
		        System.out.println("SQL Exception: " + e.getMessage());
		        e.printStackTrace();
		        // Optionally, you can throw an exception or handle the error as per your application's requirement
		    } catch (Exception e) {
		        System.out.println("Exception: " + e.getMessage());
		        e.printStackTrace();
		        // Optionally, you can throw an exception or handle the error as per your application's requirement
		    }
		}
	
	//UPDATE PARTICIPANT 
	public boolean updateBatch(Batch batch) throws SQLException{
		boolean rowUpdated;
		try(Connection con = getConnection();
				PreparedStatement statement = con.prepareStatement(UPDATE_BATCHES_SQL)){
			    
				statement.setString(1, batch.getBatchName());
				statement.setString(2, batch.getStartDate());
				statement.setString(3, batch.getEndDate());
				statement.setString(4, batch.getSessionTime());
				statement.setInt(5, batch.getBatchId());
		         //	System.out.println(statement);
			rowUpdated = statement.executeUpdate()>0;
			
			System.out.println("data updated sucessfully..");
		}
		return rowUpdated;
	}
	
	
	// SELECT_PARTICIPANT_BY_ID
	public Batch selectBatch(int batchId) {
		Batch batch = null;
		try(Connection con = getConnection();
				PreparedStatement preparedStatement = con.prepareStatement(SELECT_BATCH_BY_ID);){
			preparedStatement.setInt(1, batchId);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()){
				String batchName = rs.getString("batchName");
				String startDate = rs.getString("startDate");
				String endDate =   rs.getString("endDate");
				String sessionTime = rs.getString("sessionTime");
				batch = new Batch(batchId,batchName, startDate, endDate, sessionTime);
				System.out.println(batch.toString());
				}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return batch;
	}
	
	//SelectAllBatch
	public List<Batch> selectAllBatch() {
		List<Batch> batch = new ArrayList<>();
		try(Connection con = getConnection();
				PreparedStatement preparedStatement = con.prepareStatement(SELECT_ALL_BATCHES);){
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()){
				int batchId = rs.getInt("batchId");
				String batchName = rs.getString("batchName");
				String startDate = rs.getString("startDate");
				String endDate= rs.getString("endDate");
				String sessionTime =rs.getString("sessionTime");
				
		       batch.add(new Batch(batchId,batchName,startDate,endDate,sessionTime));
			    System.out.println(batch.toString());
		}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return batch;
	}
	
	//Delete
	public boolean deleteBatch(int batchId) throws SQLException{
		boolean rowDeleted;
		try(Connection con = getConnection();
				PreparedStatement statement = con.prepareStatement(DELETE_BATCH_SQL );){
			statement.setInt(1, batchId);			
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}	
	
	
	
	
}
	
